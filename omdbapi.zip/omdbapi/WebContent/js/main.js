var omdbapp=angular.module("omdbapi",["ngRoute"])
omdbapp.service('omdbsrvc', function($http) {
	this.search = function(params,callback) {
    	$http({
			method : "GET",
			url    :  "http://www.omdbapi.com/?apikey=6c3a2d45&plot=full&"+params
		}).then(function(response) {
			callback(response);
		})
    };
    this.getFeatured = function(callback) {
    	var movies=['rang de','Harry Potter','Pirates of','Avengers','shawshank'];
    	for(var currMovie in movies){
    		$http({
    			method : "GET",
    			url    :  "http://www.omdbapi.com/?apikey=6c3a2d45&plot=full&t="+movies[currMovie]
    		}).then(function(response) {
    			callback(response);
    		})
    	}
    };
});
omdbapp.config(function($routeProvider) {
    $routeProvider
    .when("/", {
    	templateUrl : "templates/main.html",
        controller	: "mainctrlr"
    })
    .when("/singlemovie/:movieid", {
        templateUrl : "templates/singlemovie.html",
        controller	: "singlemoviectrlr"
    })
    .when("/featured", {
        templateUrl : "templates/featured.html",
        controller	: "featuredctrlr"
    })
});
omdbapp.controller("mainctrlr",function($scope,$http,omdbsrvc){
	$scope.searchkey='';
	$scope.search=function(){
		omdbsrvc.search("t="+$scope.searchkey,$scope.searchHandler);
	}
	$scope.searchHandler=function(response){
		if(response.data.Response=="False"){
			alert(response.data.Error);
		}else{
			var url=location.href.substr(0,location.href.indexOf("#"));
			location.assign(url+"#/singlemovie/"+response.data.imdbID);
		}
	}
})
omdbapp.controller("singlemoviectrlr",function($scope,$http,$routeParams,omdbsrvc){
	$scope.moviespldata=['Genre','Actors','Plot','Language','Poster','Ratings','imdbRating'];
	$scope.movieid=$routeParams.movieid;
	$scope.moviedata={};
	$scope.tabcontent='';
	$scope.showreadmore=false;
	$scope.showreadtxt='';
	omdbsrvc.search("i="+$scope.movieid,function(response){
		$scope.moviedata=response.data;
		$scope.tabcontent=$scope.moviedata.Plot.substr(0,200)+".....";
		$scope.showreadmore=true;
		$scope.showreadtxt='Read More';
	});
	$scope.changeTabContent=function(tab){
		if(tab=="1"){
			$scope.enableReadMore();
		}
		if(tab=="2"){
			$scope.disableReadMore();
			$scope.tabcontent=$scope.moviedata.Actors;
		}
	}
	$scope.toggleReadText=function(){
		$scope.showreadtxt=($scope.showreadtxt=="Read More")?"Read Less":"Read More";
		$scope.tabcontent=($scope.showreadtxt=="Read More")?$scope.moviedata.Plot.substr(0,200)+"....":$scope.moviedata.Plot;
	}
	$scope.disableReadMore=function(){
		$scope.showreadmore=false;
		$scope.showreadtxt="Read More";
		$scope.tabcontent=$scope.moviedata.Plot.substr(0,200);
	}
	$scope.enableReadMore=function(){
		$scope.showreadmore=true;
		$scope.showreadtxt="Read More";
		$scope.tabcontent=$scope.moviedata.Plot.substr(0,200);
	}
	$scope.goBack=function(){
		window.history.back();
	}
});
omdbapp.controller("featuredctrlr",function($scope,$http,$routeParams,omdbsrvc){
	$scope.featureddata=[];
	$scope.goBack=function(){
		window.history.back();
	}
	omdbsrvc.getFeatured(function(response){
		$scope.featureddata.push(response.data);
	});
	x=$scope.featuredata;
});
omdbapp.filter('filterDisplayKeys', function() {
    return function(input) {
    	var result={};
    	var deleteItems=['Plot','Genre','Actors','Poster','Ratings','imdbRating','imdbVotes','imdbID','Type','DVD','Website','Response'];
    	angular.forEach(input, function(value, key) {
            if (deleteItems.indexOf(key)==-1) {
                result[key] = value;
            }
        });
    	return result;
    };
});
