describe('Protractor Demo App', function() {
	 it('Test featured list', function() {
		browser.get('localhost:8080/omdbapi/#/singlemovie/tt0405508');
	    expect(element(by.id('Title')).getText()).toEqual('Rang De Basanti');
	  });
});